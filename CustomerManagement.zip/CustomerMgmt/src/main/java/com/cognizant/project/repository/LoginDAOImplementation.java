package com.cognizant.project.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;




@Repository
public class LoginDAOImplementation implements LoginDAO {

	@Autowired
	SessionFactory factory;

	@Override
	public boolean validatingUser(String userName, String passWord) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project_db","root","root");
			PreparedStatement pst= con.prepareStatement("select * from Login where userName=? and passWord=?");
			pst.setString(1, userName);
			pst.setString(2, passWord);
			ResultSet rs=pst.executeQuery();
			if(rs.next()) {
				System.out.println("connected");
				return true;
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		
		
		return false;
	}
	
}
