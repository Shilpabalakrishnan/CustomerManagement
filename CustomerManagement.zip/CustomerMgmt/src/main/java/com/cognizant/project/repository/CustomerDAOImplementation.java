package com.cognizant.project.repository;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.project.entity.Customer;

@Repository
public class CustomerDAOImplementation implements CustomerDAO {

	@Autowired
	private SessionFactory factory;

	@Override
	public List<Customer> getAllCustomers() {
		Session session=factory.getCurrentSession();
		
		//HQL Query
		Query<Customer> query=session.createQuery("from Customer order by firstName",Customer.class);
		List<Customer> customerlist=query.getResultList();
		System.out.println("List of customers are :");
		customerlist.forEach(c ->System.out.println(c));
		System.out.println("customer list ended");
		return customerlist;
		
	}

	@Override
	public void saveCustomer(Customer theCustomer) {
		Session session=factory.getCurrentSession();
		session.saveOrUpdate(theCustomer);
	}


	@Override
	public List<Customer> getCustomerByName(String customerName) {
	
		Session session=factory.getCurrentSession();
		Query<Customer> query= null;
		if(customerName!=null && customerName.trim().length() >0) 
		{
			query=session.createQuery("FROM Customer WHERE customerName like concat('%',:productName,'%')",Customer.class);
			query.setParameter("customerName", customerName);
		}
		else {
			query=session.createQuery("FROM Customer",Customer.class);
		}
		List<Customer> customer=query.getResultList();
		System.out.println("onlyyyy searched");
		customer.forEach(cust->System.out.println(cust));
		return customer;
	}
	
	@Override
	public Customer getCustomer(int customerId) {
		Session session=factory.getCurrentSession();
		Customer customer=session.get(Customer.class, customerId);
		return customer;
		
	}

	@Override
	public void deleteCustomer(int customerId) {
		Session session =factory.getCurrentSession();
		Customer customer=session.get(Customer.class, customerId);
		session.delete(customer);
	}


}

