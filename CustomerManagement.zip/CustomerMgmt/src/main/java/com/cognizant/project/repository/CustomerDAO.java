package com.cognizant.project.repository;

import java.util.List;

import com.cognizant.project.entity.Customer;

public interface CustomerDAO {

	public List<Customer> getAllCustomers();

	public void saveCustomer(Customer theCustomer);

	public Customer getCustomer(int customerId);

	public void deleteCustomer(int customerId);

	public List<Customer> getCustomerByName(String customerName);

}
