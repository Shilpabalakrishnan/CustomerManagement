package com.cognizant.project.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.StringTrimmerEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;


import com.cognizant.project.entity.Customer;
import com.cognizant.project.service.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	@InitBinder
	public void doPreProcessing(WebDataBinder dataBinder)
	{
		StringTrimmerEditor ste=new StringTrimmerEditor(true);
		dataBinder.registerCustomEditor(String.class, ste);
	}
	
	@GetMapping("/customerlist")
	public String listTheCustomers(Model theModel)
	{
		List<Customer> customerList=customerService.getAllCustomers();
		theModel.addAttribute("customers",customerList);
		return "customer-list";
	}
	
	@PostMapping("/saveCustomers")
	public String saveCustomer(@Valid @ModelAttribute("customer") Customer theCustomer,BindingResult result) {
		if(result.hasErrors())
		{
			return "customer-form";
		}
	
		customerService.saveCustomer(theCustomer);
		return "redirect:/customerlist";
	}
	
	@PostMapping("/searchCustomer")
	public String searchCustomer(@RequestParam("firstName") String customerName,Model theModel) {
		List<Customer> customer=customerService.getCustomerByName(customerName);
		theModel.addAttribute("cust",customer);
		System.out.println("List");
		System.out.println(customer);
		return "customer-list";
	}
	
	@GetMapping("/customerform")
	public String addCustomers(Model theModel) {
		
		Customer customer=new Customer();
		theModel.addAttribute("customer",customer);
		return "customer-form";
	}
	
	
	@GetMapping("/updateCustomer")
	public String updateCustomer(@RequestParam("id") int customerId,Model theModel) {
		Customer customer=customerService.getCustomer(customerId);
		theModel.addAttribute("customer",customer);
		return "customer-form";
	}
	
	@GetMapping("/delete")
	public String deleteCustomer(@RequestParam("id") int customerId) {
		customerService.deleteCustomer(customerId);
		return "redirect:/customerlist";
	}
}
