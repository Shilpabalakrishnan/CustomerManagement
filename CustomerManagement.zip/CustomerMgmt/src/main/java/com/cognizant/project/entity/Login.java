package com.cognizant.project.entity;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

@Table(name="login")
public class Login {

	@Column(name="username")
	@NotBlank(message="Username shouldn't be blank")
	private String userName;
	
	@Column(name="password")
	@Pattern(regexp = "(?=^.{8,32}$)(?=.*\\d)(?=.*[!@#$%^&*]+)(?![.\\n])(?=.*[A-Z])(?=.*[a-z]).*$",
	message = "Password should have minimum 8 characters")
	private String passWord;
	

	public Login() {
		super();
	}
	
	public Login(String userName, String passWord) {
		super();
		this.userName = userName;
		this.passWord = passWord;
	}
	
	


	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}

	@Override
	public String toString() {
		return "Login [userName=" + userName + ", passWord=" + passWord + "]";
	}
	
	
}

